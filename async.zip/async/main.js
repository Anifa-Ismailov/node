const fs = require('fs');
const shell = require('shelljs')

var i;

for (i = 1; i < 4; i++) {

    testFolder = 'folder' + i + '/';

    fs.readdirSync(testFolder).forEach(file => {

        var cmd = 'node ' + testFolder + file;

        shell.exec(cmd);

    });
}

