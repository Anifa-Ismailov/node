var app = require('express')();
var http = require('http').createServer(app);
var io = require('socket.io')(http);

app.get('/', (req, res) => {
    console.log('get reqeust for root');
    // res.send('<h1>Hello world</h1>');
    let filePath = __dirname + '\\index.html'
    console.log(filePath)

    res.sendFile(__dirname + '\\index.html');
});

io.on('connection', (socket) => {
    console.log('connection process:: ')

    socket.on('chat message', (msg) => {
        console.log('message: ' + msg);
        io.emit('chat message', msg);
    });

    socket.on('disconnect', () => {
        console.log('user disconnected');
    });

});

http.listen(3000, () => {
    console.log('listening on *:3000');
});

