<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Image extends CI_Model {
	function getImages() {
		$query = $this->db->get('image');
		return $query->result();
	}

	function insertImage($file_name, $file_link) {
		$data = array(
			'name'=>$file_name,
			'link'=>$file_link
		);
		$this->db->insert('image',$data);
	}
}
