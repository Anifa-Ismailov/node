<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		$this->load->model('Image');

		$getImages = $this->Image->getImages();

		$this->load->view('welcome_message', array('getImages' => $getImages));
	}

	function do_upload()
	{

		$config['upload_path'] = './uploads/';
		$config['allowed_types'] = 'gif|jpg|png';
		$config['max_size'] = '1000000';
		$config['overwrite'] = TRUE;
		$config['encrypt_name'] = FALSE;

		if ( ! is_dir($config['upload_path']) ) die("THE UPLOAD DIRECTORY DOES NOT EXIST");

		$this->load->library('upload', $config);

		if ( ! $this->upload->do_upload('userfile')) {

			echo 'error';

		} else {

			$this->upload->data();

			$file_name = $_FILES['userfile']['name'];

			$this->load->model('Image');

			$file_link = 'uploads/'.$file_name;

			$this->Image->insertImage($file_name, $file_link);

			redirect(base_url());

		}
	}
}
